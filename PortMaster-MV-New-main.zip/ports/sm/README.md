## Notes

Thanks to the [SNESREV project](https://github.com/snesrev/sm).

## Installation

To make it work just copy the Super Metroid US rom renamed as sm.smc in the root folder.
For redux same thing, but use the redux Rom.
